<footer>
        <div class="container bg-dark text-white">
         <div class="row">
             <div class="col-1"></div>
             <div class="col-4">                    
                <div class ="copy">
                <p class = "p1">
                Copyright <?php echo '&copy2023'; ?>
                </p>
            </div></div>  
             <div class="col-4">
                <div class="text">
                    <p>Контакты:</p>
                    <p>г. Москва</p>
                    <a class="phone" href="#"><i class="fa fa-phone"></i>+790359444</a>&nbsp;&nbsp; 
                </div>
             </div>
             <div class="col-2"></div>    
             <div class="col-1"></div>
         </div>
     </div>
    </footer>
</body>
</html>