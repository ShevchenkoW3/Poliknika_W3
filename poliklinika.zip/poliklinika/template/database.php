<?php
$mysqli=new mysqli ("localhost", "root", "","poliklinika");
$mysqli->set_charset("utf8");
?>