<?php
    session_start();
?>
<header>
        <div class="container mb-5">
            <div class="row">
                <div >
                   <nav class="navbar navbar-expand-lg navbar-dark  text-white bg-dark">
                    <div class="container-fluid">
                        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                        </button>
                        <div class="collapse navbar-collapse" id="navbarNav">
                        <ul class="navbar-nav">
                            <?php
                                if (!empty($_SESSION['role'])) {
                                if ($_SESSION['role'] == "продавец") {
                                    echo '
                                        <li class="nav-item">
                                        <a class="nav-link" aria-current="page" href="allorders.php">заказы</a>
                                        </li>
                                    ';
                                }
                                elseif ($_SESSION['role'] == "покупатель") {
                                    echo '
                                        <li class="nav-item">
                                        <a class="nav-link " aria-current="page" href="index.php">главная</a>
                                        </li>
                                        <li class="nav-item">
                                        <a class="nav-link " aria-current="page" href="trades.php">товары</a>
                                        </li>
                                        <li class="nav-item">
                                        <a class="nav-link " aria-current="page" href="orders.php">Заказы</a>
                                        </li>
                                    ';
                                }
                                    echo '
                                        <li class="nav-item">
                                        <a class="nav-link " aria-current="page" href="login.php">Выйти</a>
                                        </li>
                                    ';
                                }
                                else{
                                    echo '
                                        <li class="nav-item">
                                        <a class="nav-link " aria-current="page" href="login.php">Войти</a>
                                        </li>
                                        <li class="nav-item">
                                        <a class="nav-link " aria-current="page" href="registr.php">Регистрация</a>
                                        </li>
                                        
                                    
                                    ';
                                }
                            ?>
                        </ul>
                        </div>
                    </div>
                    </nav>
                </div>
            </div>
        </div>
    </header> 